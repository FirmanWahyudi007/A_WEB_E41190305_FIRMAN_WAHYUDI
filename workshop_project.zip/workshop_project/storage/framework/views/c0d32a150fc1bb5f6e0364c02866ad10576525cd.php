<?php echo $__env->make('backend/layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<main class="content-wrapper">
    <div class="mdc-layout-grid">
        <div class="mdc-layout-grid__inner">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>
</main>
<?php echo $__env->make('backend/layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\A_WEB_E41190305_FIRMAN_WAHYUDI\workshop_project\resources\views/backend/layouts/template.blade.php ENDPATH**/ ?>